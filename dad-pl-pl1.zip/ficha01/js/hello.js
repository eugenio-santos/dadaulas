(function() {
    'use strict';
    document.write('<h2>Hello World</h2>');
})();
